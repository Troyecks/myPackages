# Description of mypackage

This is a package to show how to set up a package and distribute it in github
